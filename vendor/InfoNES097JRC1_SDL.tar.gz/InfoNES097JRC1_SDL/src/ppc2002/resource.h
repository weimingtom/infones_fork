//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by InfoNES2002.rc
//
#define IDI_INFONES2002                 101
#define IDM_MENU                        102
#define IDD_ABOUTBOX                    103
#define IDS_HELP                        104
#define IDD_KEY_CONFIG                  105
#define IDD_KEY_PRESS                   107
#define IDS_COMMAND1                    301
#define IDC_STATIC_KEY_A                1001
#define IDC_STATIC_KEY_B                1002
#define IDC_STATIC_KEY_SELECT           1003
#define IDC_STATIC_KEY_START            1004
#define IDC_STATIC_KEY_UP               1005
#define IDC_STATIC_KEY_DOWN             1006
#define IDC_STATIC_KEY_LEFT             1007
#define IDC_STATIC_KEY_RIGHT            1008
#define IDC_STATIC_KEY_EXIT             1009
#define IDC_A                           1021
#define IDC_B                           1022
#define IDC_SELECT                      1023
#define IDC_START                       1024
#define IDC_UP                          1025
#define IDC_DOWN                        1026
#define IDC_LEFT                        1027
#define IDC_RIGHT                       1028
#define IDC_EXIT                        1029
#define IDC_DEL_A                       1031
#define IDC_DEL_B                       1032
#define IDC_DEL_SELECT                  1033
#define IDC_DEL_START                   1034
#define IDC_DEL_UP                      1035
#define IDC_DEL_DOWN                    1036
#define IDC_DEL_LEFT                    1037
#define IDC_DEL_RIGHT                   1038
#define IDC_DEL_EXIT                    1039
#define IDM_MAIN_COMMAND1               40001
#define IDM_HELP_ABOUT                  40003
#define ID_MENUITEM40004                40004
#define IDS_MENUITEM40005               40006
#define IDS_MENU_FILE                   40006
#define IDM_MAIN_END                    40007
#define IDM_MAIN_RESET                  40008
#define IDM_MAIN_RESUME                 40009
#define ID_MENUITEM40010                40010
#define IDS_MENUITEM40011               40012
#define IDM_MAIN_FRAME_0                40013
#define IDM_MAIN_FRAME_1                40014
#define IDM_MAIN_FRAME_2                40015
#define IDM_MAIN_FRAME_3                40016
#define IDM_MAIN_FRAME_4                40017
#define IDM_MAIN_FRAME_5                40018
#define IDM_MAIN_FRAME_8                40019
#define IDM_MAIN_FRAME_10               40020
#define ID_FILE                         40021
#define IDM_MAIN_SOUND                  40022
#define IDM_MAIN_KEY_CONFIG             40023
#define ID_OPTION                       40025
#define IDS_MENUITEM40026               40027
#define IDS_MENU_OPTION                 40027
#define IDM_MAIN_SCREEN_CLIP            40028
#define IDM_MAIN_CLIP                   40028
#define IDM_MAIN_VERSION                40029
#define IDM_MAIN_ROM                    40030

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40031
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
