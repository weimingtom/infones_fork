//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by InfoNES_Resource_Win.rc
//
#define IDR_MENU                        102
#define IDD_DIALOG                      104
#define IDB_BITMAP1                     105
#define IDB_BITMAP                      105
#define IDI_ICON                        106
#define IDC_OK                          1003
#define IDC_BTN_STOP                    40001
#define IDC_BTN_FAST                    40002
#define IDC_BTN_SLOW                    40003
#define IDC_BTN_ABOUT                   40004
#define IDC_BTN_SINGLE                  40006
#define IDC_BTN_DOUBLE                  40007
#define IDC_BTN_TRIPLE                  40008
#define IDC_BTN_CLIP_VERTICAL           40010
#define IDC_BTN_FRAMESKIP               40011
#define IDC_BTN_MUTE                    40012
#define IDC_BTN_INFO                    40013
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40014
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
